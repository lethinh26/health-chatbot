from guide import get_guide
from typing import Dict, Any, List
from utils import normalize
import re
from typing import Dict, Any, List
from tools import advice_for_metric, lifestyle_config, metrics_synonyms, metrics_synonyms, metrics_synonyms, metrics_synonyms, metrics_synonyms

def execute(intent_id: str, slots: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    # ---- GREET.SMALLTALK ----
    if intent_id == "greet.smalltalk":
        text = "Xin chào! Mình có thể giúp bạn đọc kết quả xét nghiệm, xem chỉ số (BMI, huyết áp, đường huyết…), hoặc hướng dẫn sử dụng hệ thống."
        suggestions = [
            "tổng hợp lời khuyên từ xét nghiệm của tôi",
            "BMI của tôi",
            "Huyết áp của tôi",
            "Hướng dẫn tôi đăng ký"
        ]
        explanations = [text]
        return {
            "no_data": False,
            "explanations": explanations,
            "targets": [f"Hỏi: “{s}”" for s in suggestions]
        }

    # ---- LABS.SUMMARY (per-metric) ----
    if intent_id == "labs.summary":
        syn = metrics_synonyms()
        metrics = list(syn.keys())
        numbers = []
        actions: List[str] = []
        cautions: List[str] = []
        explanations: List[str] = ["Tổng hợp lời khuyên về xét nghiệm"]
        items: List[Dict[str, Any]] = []

        NORMAL_IDS = {"normal", "optimal", "good", "target"}
        NORMAL_LABELS = {"bình thường", "binh thuong", "normal", "tối ưu", "toi uu", "optimal"}

        for mid in metrics:
            info = advice_for_metric(mid, profile)
            title = info.get("title") or mid
            val, unit, date = info.get("number", (None, None, None))
            label = (info.get("label") or "") or None
            cat_id = (info.get("category_id") or "") or None

            actions.extend(info.get("tips") or [])
            cautions.extend(info.get("cautions") or [])

            status = None
            if label or cat_id or val is not None:
                if (cat_id and str(cat_id).lower() in NORMAL_IDS) or (label and str(label).lower() in NORMAL_LABELS):
                    status = "good"
                else:
                    status = "not_good"

            first_tip = (info.get("tips") or [None])[0]
            if status:
                items.append({
                    "metric": mid,
                    "title": title,
                    "value": val,
                    "unit": unit,
                    "date": date,
                    "status": status,
                    "label": label,
                    "advice_top": first_tip,
                })

            if val is not None:
                numbers.append({"name": title, "value": val, "unit": unit, "date": date})

        # sort: show 'not_good' first
        items.sort(key=lambda x: 0 if x.get("status") == "not_good" else 1)

        # de-dup
        def _dedup(seq):
            seen = set(); out = []
            for x in seq:
                if x and x not in seen:
                    out.append(x); seen.add(x)
            return out

        actions = _dedup(actions)[:10]
        cautions = _dedup(cautions)[:6]

        if not items and not actions and not cautions:
            ls = lifestyle_config()
            actions = _dedup((ls.get("diet_general") or []) + (ls.get("physical_activity") or []))[:8]
            cautions = _dedup(ls.get("general_warnings") or [])[:5]

        return {
            "no_data": False,
            "numbers": numbers,
            "classification": {"items": items},
            "actions": actions,
            "cautions": cautions,
            "explanations": explanations,
        }

    # ---- VITAL.QUERY ----
    if intent_id == "vital.query":
        metric = (slots or {}).get("metric")
        kind = (slots or {}).get("query_kind") or "value"
        if not metric:
            syn = metrics_synonyms()
            q = (slots or {}).get("q") or ""
            for mid, kws in syn.items():
                if any((k.lower() in q.lower()) for k in (kws or [])):
                    metric = mid; break
        if not metric:
            return {"no_data": True, "explanations": ["Xin lỗi, mình chưa biết trả lời câu này."]}

        info = advice_for_metric(metric, profile)
        title = info.get("title") or metric
        val, unit, date = info.get("number", (None, None, None))
        label = info.get("label")
        cat_id = info.get("category_id")

        actions: List[str] = (info.get("tips") or [])[:5]
        cautions: List[str] = (info.get("cautions") or [])[:5]

        if val is None and label is None:
            return {"no_data": True, "explanations": [f"Chưa tìm thấy dữ liệu cho {title}."]}

        msg = None
        if val is not None:
            msg = f"{title} gần nhất: {val}{(' ' + unit) if unit else ''}" + (f" (ngày {date})" if date else "")
            if kind == "classification" and label:
                msg += f". Phân loại: {label}."
        elif label:
            msg = f"{title}: {label}."
        explanations = [msg]

        numbers = []
        if val is not None:
            numbers = [{"name": title, "value": val, "unit": unit, "date": date}]

        classification = {}
        if label or cat_id:
            classification = {"label": label, "category_id": cat_id}

        return {
            "no_data": False,
            "numbers": numbers,
            "actions": actions,
            "cautions": cautions,
            "explanations": explanations,
            "classification": classification,
        }

    # ---- GUIDE.QUERY ----
    if intent_id == "guide.query":
        topic_raw = (slots or {}).get("topic_id") or ""
        # Normalize with unidecode via utils.normalize
        def _norm_id(s: str) -> str:
            s = normalize(s or "")  # remove diacritics, lower, trim
            s = s.replace("-", " ").replace("/", " ").replace("\\", " ")
            s = re.sub(r"\s+", " ", s).strip()
            s = s.replace(" ", "_")
            return s

        tid = _norm_id(topic_raw)

        titles = {
            "register": "Hướng dẫn: Đăng ký tài khoản HMS",
            "login": "Hướng dẫn: Đăng nhập HMS",
            "book_appointment": "Hướng dẫn: Đặt lịch khám trên HMS",
            "health_recommendation": "Hướng dẫn: Xem lời khuyên sức khỏe (Health Recommendation)",
            "update_profile": "Hướng dẫn: Cập nhật hồ sơ cá nhân trên HMS",
            "register_doctor": "Hướng dẫn: Đăng ký trở thành bác sĩ trên HMS",
        }
        steps = {
            "register": [
                "Vào trang **Đăng ký** trên HMS Web.",
                "Nhập **email/số điện thoại** và **mật khẩu**.",
                "Nhập **OTP** (nếu được yêu cầu) để xác thực.",
                "Đăng nhập và **hoàn tất hồ sơ** (họ tên, ngày sinh...)."
            ],
            "login": [
                "Vào trang **Đăng nhập** trên HMS Web.",
                "Nhập **email/số điện thoại** và **mật khẩu**.",
                "Nếu quên mật khẩu: chọn **Quên mật khẩu** để nhận OTP / đặt lại."
            ],
            "book_appointment": [
                "Từ **Dashboard** → mở **Lịch khám**.",
                "Chọn **chuyên khoa/bác sĩ** và **thời gian** phù hợp.",
                "Xác nhận lịch và theo dõi **thông báo** trên HMS."
            ],
            "health_recommendation": [
                "Từ **Dashboard** → mở **Health Recommendation**.",
                "Xem gợi ý **dinh dưỡng, vận động, giấc ngủ** theo chỉ số cá nhân.",
                "Cập nhật **BMI, huyết áp, đường huyết**… để hệ thống đề xuất chính xác hơn."
            ],
            "update_profile": [
                "Vào **Hồ sơ cá nhân** trên HMS Web.",
                "Chỉnh sửa **chiều cao, cân nặng**, tiền sử bệnh (nếu có).",
                "Nhấn **Lưu** để áp dụng vào khuyến nghị."
            ],
            "register_doctor": [
                "Vào trang **Bác sĩ/Đối tác** trên HMS Web.",
                "Chọn **Đăng ký bác sĩ**, điền thông tin **hành nghề** và **phòng khám**.",
                "Tải lên **chứng chỉ hành nghề** / giấy tờ liên quan.",
                "Đặt **lịch làm việc** (khung giờ nhận lịch).",
                "Gửi hồ sơ và **chờ duyệt** từ quản trị hệ thống."
            ],
        }

        # Alias sets (after normalization)
        ALIASES = {
            "register": {
                "register", "dang_ky", "dangki", "dang_ki", "dangky_tai_khoan", "tao_tai_khoan", "sign_up", "signup"
            },
            "login": {"login", "dang_nhap", "signin", "sign_in"},
            "book_appointment": {"book_appointment", "dat_lich", "dat_lich_kham", "dat_kham", "dat_bac_si"},
            "health_recommendation": {
                "health_recommendation", "xem_loi_khuyen", "xem_khuyen_nghi", "khuyen_nghi_suc_khoe", "loi_khuyen"
            },
            "update_profile": {"update_profile", "cap_nhat_ho_so", "sua_ho_so", "chinh_sua_ho_so"},
            "register_doctor": {
                "register_doctor", "dang_ky_bac_si", "dang_ki_bac_si", "tro_thanh_bac_si", "lam_bac_si",
                "dang_ky_bac_sy", "dang_ki_bac_sy", "dang_ky_bac_s", "dang_ki_bac_s"
            },
        }

        def _resolve_key(tid: str) -> str:
            # Direct alias match
            for canon, aset in ALIASES.items():
                if tid in aset:
                    return canon
            # Pattern-based heuristics
            if any(k in tid for k in ["dang_ky_bac", "dang_ki_bac", "lam_bac_si", "tro_thanh_bac_si"]):
                return "register_doctor"
            if any(k in tid for k in ["dang_ky", "dangki", "dang_ki", "sign_up", "signup", "tao_tai_khoan"]):
                return "register"
            if any(k in tid for k in ["dang_nhap", "signin", "sign_in", "login"]):
                return "login"
            if any(k in tid for k in ["dat_lich", "dat_kham", "appointment", "dat_bac_si"]):
                return "book_appointment"
            if any(k in tid for k in ["cap_nhat_ho_so", "update_profile", "profile", "sua_ho_so", "chinh_sua_ho_so"]):
                return "update_profile"
            if any(k in tid for k in ["loi_khuyen", "khuyen_nghi", "recommendation", "health_recommendation"]):
                return "health_recommendation"
            return "health_recommendation"

        key = _resolve_key(tid)
        explanation = titles.get(key, "Hướng dẫn: Sử dụng HMS")
        return {
            "no_data": False,
            "explanations": [explanation],
            "targets": steps.get(key, ["Nếu cần thêm trợ giúp, vui lòng liên hệ hỗ trợ."]),
        }

    # ---- default fallback ----
    return {"no_data": True, "explanations": ["Xin lỗi, mình chưa biết trả lời câu này."]}
