from typing import Dict, Tuple
import os, yaml
from utils import normalize, contains_any
from guide import classify_topic
from tools import metrics_synonyms, lifestyle_config

def _load_router_cfg() -> dict:
    path = os.path.join("schemas", "router.yaml")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}

_CFG = _load_router_cfg()

_BMI_CLASSIFY_KEYS = [str(x) for x in (_CFG.get("bmi_classification_keywords") or ["gay","gầy","beo","béo","thua can","thừa cân","overweight","underweight","obese","beo phi","béo phì"])]
_GREETING_SET = set([normalize(s) for s in (_CFG.get("greeting_synonyms") or ["xin chao","chao","chao ban","hello","hi","alo"])])
_LAB_SUMMARY_SYNS = [str(x) for x in (_CFG.get("lab_summary_synonyms") or ["tong hop loi khuyen ve xet nghiem","tong hop xet nghiem","tom tat xet nghiem","ket luan xet nghiem","tong hop loi khuyen xet nghiem","tong hop loi khuyen"])]

def _is_greeting_only(q: str) -> bool:
    qn = normalize(q)
    qn = " ".join(qn.split())
    return qn in _GREETING_SET

def detect_intent(question: str) -> Tuple[str, Dict]:
    qn = normalize(question)

    # 1) Greeting-only
    if _is_greeting_only(qn):
        return "greet.smalltalk", {}

    # 2) Lab summary (ưu tiên hơn guide topics)
    if contains_any(qn, _LAB_SUMMARY_SYNS):
        return "labs.summary", {}

    # 3) Topic guide
    topic_id = classify_topic(qn)
    if topic_id:
        return "guide.query", {"topic_id": topic_id}

    # 4) Vital metrics
    syn = metrics_synonyms()
    for metric_id, kw_list in syn.items():
        if contains_any(qn, kw_list):
            kind = "classification" if (metric_id == "bmi" and contains_any(qn, _BMI_CLASSIFY_KEYS)) else "value"
            return "vital.query", {"metric": metric_id, "query_kind": kind}

    # 5) Lifestyle
    ls = lifestyle_config()
    if contains_any(qn, ls.get("synonyms", [])):
        return "lifestyle.advice", {}

    # 6) Fallback
    return "greet.smalltalk", {}
