# Python 12

```bash
python -m venv health-chatbot
pip install -r requirements.txt
uvicorn main:app 
```
# Config PowerShell
```bash
$token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZHNhbmcxOTk5QGdtYWlsLmNvbSIsInJvbGVzIjpbIkFkbWluIl0sImV4cCI6MTc1NjgyNjUyMX0.Wl9Tm21tLiySh6P5My6010fSHrhnzfWzhPwR2cvufPI"
$id = "00-0001"

curl.exe -X POST "http://127.0.0.1:8000/ask" `
   -H "Authorization: Bearer $token" `
   -H "Patient-Id: $id" `
   -F "question=Chiều cao của tôi"
```


# Note
## optimize -> optimize
## note -> fix hoặc rewrite: being process